const sql = require('mssql');
const poolPromise = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    const { username, email, password, firstName, lastName, mobileNumber } = req.body;
    try {
        const pool = await poolPromise;
        const hash = await bcrypt.hash(password, 10);
        const result = await pool.request()
            .input('Username', sql.VarChar, username)
            .input('Email', sql.VarChar, email)
            .input('PasswordHash', sql.VarChar, hash)
            .input('FirstName', sql.VarChar, firstName)
            .input('LastName', sql.VarChar, lastName)
            .input('MobileNumber', sql.VarChar, mobileNumber)
            .query(`
                INSERT INTO Users (Username, Email, PasswordHash, FirstName, LastName, MobileNumber)
                VALUES (@Username, @Email, @PasswordHash, @FirstName, @LastName, @MobileNumber);
                SELECT SCOPE_IDENTITY() as UserID
            `);
        const userId = result.recordset[0].UserID;
        const token = jwt.sign({ userId }, 'your_jwt_secret', { expiresIn: '1h' });
        res.status(201).json({ message: 'User registered', token });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('Username', sql.VarChar, username)
            .query('SELECT * FROM Users WHERE Username = @Username');
        if (!result.recordset[0]) return res.status(401).json({ error: 'Invalid credentials' });
        const user = result.recordset[0];
        const match = await bcrypt.compare(password, user.PasswordHash);
        if (!match) return res.status(401).json({ error: 'Invalid credentials' });
        const token = jwt.sign({ userId: user.UserID }, 'your_jwt_secret', { expiresIn: '1h' });
        res.json({ message: 'Login successful', token });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};